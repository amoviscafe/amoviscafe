setTimeout(() => {
  window.location.href = "home.html";
}, 3000);
