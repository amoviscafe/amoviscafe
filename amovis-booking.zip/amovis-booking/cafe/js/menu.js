import { db } from "./firebase.js";
import {
  collection,
  addDoc,
  serverTimestamp
} from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";

let cart = [];
let total = 0;

const cartDiv = document.getElementById("cart");
const totalSpan = document.getElementById("total");

// ✅ ADD BUTTONS WORK
document.querySelectorAll(".add-btn").forEach(btn => {
  btn.addEventListener("click", () => {
    const name = btn.dataset.name;
    const price = Number(btn.dataset.price);

    cart.push({ name, price, qty: 1 });
    total += price;

    renderCart();
  });
});

function renderCart() {
  cartDiv.innerHTML = "";
  cart.forEach(item => {
    const p = document.createElement("p");
    p.textContent = `${item.name} - ₹${item.price}`;
    cartDiv.appendChild(p);
  });
  totalSpan.textContent = total;
}

// ✅ PLACE ORDER WORKS
document.getElementById("placeOrder").addEventListener("click", async () => {
  if (cart.length === 0) {
    alert("Cart empty");
    return;
  }

  await addDoc(collection(db, "orders"), {
    tableNo: "Table 1",
    items: cart,
    total: total,
    status: "NEW",
    createdAt: serverTimestamp()
  });

  alert("Order placed!");

  cart = [];
  total = 0;
  renderCart();
});