import { db } from "./firebase.js";
import {
  collection,
  query,
  where,
  onSnapshot,
  updateDoc,
  doc
} from "https://www.gstatic.com/firebasejs/10.7.1/firebase-firestore.js";

const list = document.getElementById("ordersList");

const q = query(
  collection(db, "orders"),
  where("status", "in", ["NEW", "PREPARING"])
);

onSnapshot(q, (snapshot) => {
  list.innerHTML = "";

  snapshot.forEach((d) => {
    const o = d.data();

    const div = document.createElement("div");
    div.className = "order-card";

    div.innerHTML = `
      <h3>🪑 ${o.tableNo}</h3>
      <ul>
        ${o.items.map(i => `<li>${i.name} x${i.qty}</li>`).join("")}
      </ul>
      <b>Total: ₹${o.total}</b><br><br>
      <button onclick="markPreparing('${d.id}')">PREPARING</button>
      <button onclick="markReady('${d.id}')">READY</button>
    `;

    list.appendChild(div);
  });
});

// 🔊 SOUND ALERT
const beep = new Audio("../assets/order.mp3");

onSnapshot(
  query(collection(db,"orders"), where("status","==","NEW")),
  snap => {
    if(!snap.empty) beep.play();
  }
);

// ACTIONS
window.markPreparing = async (id)=>{
  await updateDoc(doc(db,"orders",id),{status:"PREPARING"});
};

window.markReady = async (id)=>{
  await updateDoc(doc(db,"orders",id),{status:"READY"});
};
