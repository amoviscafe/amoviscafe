/* ================= CONFIG ================= */
const TOTAL_TABLES = 15;

/* CHANGE THIS TO YOUR MENU PAGE */
const MENU_URL = "https://parthahoke.github.io/amovis-cafe/menu.html";

/* ================= INIT ================= */
const grid = document.getElementById("tableGrid");

/* ================= CREATE TABLE CARDS ================= */
for(let i=1;i<=TOTAL_TABLES;i++){

  const card = document.createElement("div");
  card.className = "card";

  card.innerHTML = `
    <h3>TABLE NO : ${i}</h3>

    <div class="qr-box">
      <div class="qr-inner" id="qr-${i}"></div>
    </div>

    <button onclick="downloadQR(${i})">
      ⬇️ Download QR
    </button>
  `;

  grid.appendChild(card);

  /* CREATE QR */
  new QRCode(document.getElementById(`qr-${i}`),{
    text: `${MENU_URL}?table=${i}`,
    width:160,
    height:160,
    colorDark:"#4c1d95",
    colorLight:"#ffffff",
    correctLevel: QRCode.CorrectLevel.H
  });
}

/* ================= DOWNLOAD QR ================= */
function downloadQR(tableNo){

  const qrDiv = document.getElementById(`qr-${tableNo}`);
  const img = qrDiv.querySelector("img");

  if(!img){
    alert("QR not ready");
    return;
  }

  /* CREATE CANVAS */
  const canvas = document.createElement("canvas");
  const size = 320;
  canvas.width = size;
  canvas.height = size + 80;
  const ctx = canvas.getContext("2d");

  /* BACKGROUND */
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0,0,canvas.width,canvas.height);

  /* TITLE */
  ctx.fillStyle = "#4c1d95";
  ctx.font = "bold 22px Poppins";
  ctx.textAlign = "center";
  ctx.fillText("Amovi's Cafe & Fast Food", size/2, 30);

  ctx.font = "bold 18px Poppins";
  ctx.fillText(`TABLE NO : ${tableNo}`, size/2, 55);

  /* DRAW QR */
  const qrImg = new Image();
  qrImg.src = img.src;

  qrImg.onload = ()=>{
    ctx.drawImage(qrImg,40,70,240,240);

    /* DOWNLOAD */
    const link = document.createElement("a");
    link.download = `Table_${tableNo}_QR.png`;
    link.href = canvas.toDataURL("image/png");
    link.click();
  };
}