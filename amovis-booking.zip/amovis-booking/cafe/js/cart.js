import { 
  getFirestore, 
  collection, 
  addDoc, 
  serverTimestamp 
} from "https://www.gstatic.com/firebasejs/9.23.0/firebase-firestore.js";

import { app } from "./firebase.js";

const db = getFirestore(app);

// 🔥 CART ITEMS (memory only)
let cart = [];

// 🔹 Add item from menu
window.addToCart = function(name, price) {
  const found = cart.find(i => i.name === name);
  if (found) {
    found.qty += 1;
  } else {
    cart.push({ name, price, qty: 1 });
  }
  renderCart();
};

// 🔹 Render cart UI
function renderCart() {
  const list = document.getElementById("cartItems");
  const totalEl = document.getElementById("totalAmount");

  list.innerHTML = "";
  let total = 0;

  cart.forEach(item => {
    total += item.price * item.qty;

    const li = document.createElement("li");
    li.innerHTML = `
      ${item.name} × ${item.qty}
      <span>₹${item.price * item.qty}</span>
    `;
    list.appendChild(li);
  });

  totalEl.innerText = "₹" + total;
}

// 🔹 PLACE ORDER → FIRESTORE
window.placeOrder = async function() {
  if (cart.length === 0) {
    alert("Cart is empty");
    return;
  }

  const tableNo = new URLSearchParams(window.location.search).get("table");

  if (!tableNo) {
    alert("Table number missing");
    return;
  }

  const total = cart.reduce(
    (sum, i) => sum + i.price * i.qty, 
    0
  );

  try {
    await addDoc(collection(db, "orders"), {
      tableNo,
      items: cart,
      total,
      status: "PENDING",
      createdAt: serverTimestamp()
    });

    alert("Order placed successfully 🍽️");
    cart = [];
    renderCart();

  } catch (err) {
    console.error(err);
    alert("Order failed");
  }
};
