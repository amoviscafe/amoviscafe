const billsDiv = document.getElementById("bills");
const emptyDiv = document.getElementById("empty");

db.collection("orders")
  .where("status","==","READY")
  .orderBy("createdAt","asc")
  .onSnapshot(snapshot=>{
    billsDiv.innerHTML = "";

    if(snapshot.empty){
      emptyDiv.style.display = "block";
      return;
    }

    emptyDiv.style.display = "none";

    snapshot.forEach(doc=>{
      const o = doc.data();

      let itemsHTML = "";
      o.items.forEach(i=>{
        itemsHTML += `<div>• ${i.name} × ${i.qty} = ₹${i.price * i.qty}</div>`;
      });

      billsDiv.innerHTML += `
        <div class="bill">
          <h3>🪑 Table ${o.tableNo}</h3>

          <div class="items">${itemsHTML}</div>

          <div class="total">Total: ₹${o.total}</div>

          <select id="pay-${doc.id}">
            <option value="Cash">Cash</option>
            <option value="UPI">UPI</option>
          </select>

          <button class="complete" onclick="completeOrder('${doc.id}')">
            Complete & Save
          </button>
        </div>
      `;
    });
  });

function completeOrder(id){
  const mode = document.getElementById(`pay-${id}`).value;

  db.collection("orders").doc(id).update({
    status: "COMPLETED",
    paymentMode: mode,
    completedAt: firebase.firestore.FieldValue.serverTimestamp()
  });
}