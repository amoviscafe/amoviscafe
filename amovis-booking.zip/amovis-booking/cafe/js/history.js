const list = document.getElementById("orderList");
const empty = document.getElementById("empty");

const totalOrdersEl = document.getElementById("totalOrders");
const totalSalesEl = document.getElementById("totalSales");

let allOrders = [];

/* ================= LOAD COMPLETED ORDERS ================= */
db.collection("orders")
  .where("status", "==", "completed")   // ✅ FIXED (case)
  .orderBy("completedAt", "desc")
  .onSnapshot(snapshot => {
    allOrders = [];
    snapshot.forEach(doc => {
      allOrders.push({
        id: doc.id,
        ...doc.data()
      });
    });
    render(allOrders);
  });

/* ================= RENDER ================= */
function render(data) {
  list.innerHTML = "";
  let total = 0;

  if (!data.length) {
    empty.style.display = "block";
    totalOrdersEl.innerText = "0";
    totalSalesEl.innerText = "₹0";
    return;
  }

  empty.style.display = "none";

  data.forEach(o => {
    total += Number(o.total);

    let itemsHTML = "";

    /* ✅ FIXED ITEMS OBJECT */
    for (let name in o.items) {
      let i = o.items[name];
      itemsHTML += `<div>• ${name} × ${i.qty}</div>`;
    }

    list.innerHTML += `
      <div class="order">
        <h4>🪑 Table ${o.tableNo || "-"}</h4>

        <div class="items">${itemsHTML}</div>

        <div class="meta">
          💳 ${o.paymentMode || "-"} <br>
          🕒 ${
            o.completedAt
              ? o.completedAt.toDate().toLocaleString()
              : "-"
          }
        </div>

        <div class="total">₹${o.total}</div>
      </div>
    `;
  });

  totalOrdersEl.innerText = data.length;
  totalSalesEl.innerText = "₹" + total;
}

/* ================= FILTERS ================= */
function applyFilters() {
  const from = document.getElementById("fromDate").value;
  const to = document.getElementById("toDate").value;
  const table = document.getElementById("tableFilter").value;
  const pay = document.getElementById("paymentFilter").value;

  let filtered = [...allOrders];

  if (from) {
    const f = new Date(from);
    filtered = filtered.filter(o => o.completedAt?.toDate() >= f);
  }

  if (to) {
    const t = new Date(to);
    t.setHours(23, 59, 59, 999);
    filtered = filtered.filter(o => o.completedAt?.toDate() <= t);
  }

  if (table) {
    filtered = filtered.filter(o => o.tableNo == table);
  }

  if (pay) {
    filtered = filtered.filter(o => o.paymentMode === pay);
  }

  render(filtered);
}